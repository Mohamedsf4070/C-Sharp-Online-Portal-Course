﻿using System;
namespace OnlinePortalAssignment
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter your Grade:");
            char grade=Convert.ToChar(Console.ReadLine().ToUpper());
            if(grade=='A')
            {
                Console.WriteLine("It denotes 9 points");
            }
            else if(grade=='B')
            {
            Console.WriteLine("It denotes 8 points");
            }
            else if(grade=='C')
            {
                Console.WriteLine("It denotes 7 Points");
            }
            else if(grade=='D')
            {
                Console.WriteLine("It denotes 6 points");
            }
            else
            {
                Console.WriteLine("Invalid Grade");
            }
        }
    }
}