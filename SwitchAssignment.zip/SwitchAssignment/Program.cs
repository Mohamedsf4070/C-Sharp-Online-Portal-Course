﻿using System;
namespace SwitchAssignment
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Enter Number One:");
            int numOne=Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number Two:");
            int numTwo=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("1.Add  2.Subtract  3.Multiply 4.Divide");
            Console.Write("Enter Your Option:");
            int Option=Convert.ToInt32(Console.ReadLine());
            switch(Option)
            {
                case 1:
                {
                    Console.WriteLine("The Addition of Two Numbers Are:"+(numOne+numTwo));
                    break;
                }
                case 2:
                {
                    Console.WriteLine("The Subtraction of Two Numbers Are:"+(numOne-numTwo));
                    break;
                }
                case 3:
                {
                    Console.WriteLine("The Multiplication of Two Numbers Are:"+(numOne*numTwo));
                    break;
                }
                case 4:
                {
                    Console.WriteLine("The Division of Two Numbers Are:"+(numOne/numTwo));
                    break;
                }
                default:
                {
                    Console.WriteLine("YOu have entered Wring Option");
                    break;
                }
            }
        }
    }
}