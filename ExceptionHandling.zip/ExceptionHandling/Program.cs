﻿using System;
namespace ExceptionHandling
{
    class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Two numbers:");
                Console.Write("Enter Number One:");
                int numOne=Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter number Two:");
                int numTwo=Convert.ToInt32(Console.ReadLine());
                int divident=numOne/numTwo;

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}