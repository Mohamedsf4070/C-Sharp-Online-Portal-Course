﻿using System;
namespace OnlineArrayAssignment2
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter ten Numbers That have to be Arranged:");
            int[] arr=new int[10];
            for(int i=0;i<10;i++)
            {
                arr[i]=Convert.ToInt32(Console.ReadLine());
            }
            int count=0;
            for(int i=0;i<10;i++)
            {
                if(arr[i]%2==0)
                {
                    int temp=arr[i];
                    arr[i]=arr[count];
                    arr[count]=temp;
                    count++;
                }
            }
            Console.WriteLine("Ascending order of Even Numbers:");
            for(int j=0;j<count;j++)
            {
              for(int k=j;k<count;k++)
              {
                if(arr[j]>arr[k])
                {
                    int temp=arr[k];
                    arr[k]=arr[j];
                    arr[j]=temp;
                }
              }
              Console.Write(arr[j]+" ");
            }
            Console.WriteLine("\nDecending Order Of Odd Number:");
             for(int j=count;j<arr.Length;j++)
            {
              for(int k=j;k<arr.Length;k++)
              {
                if(arr[j]<arr[k])
                {
                    int temp=arr[k];
                    arr[k]=arr[j];
                    arr[j]=temp;
                }
              }
              Console.Write(arr[j]+" ");
            }
        }
    }
}