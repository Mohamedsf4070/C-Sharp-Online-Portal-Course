﻿using System;
namespace ArrayAssignment1
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the Ten Element that have to be Sorted:");
            int[] arr=new int[10];
            for(int i=0;i<10;i++)
            {
                arr[i]=Convert.ToInt32(Console.ReadLine());
            }
               
           for(int i=0;i<arr.Length;i++)
            {
                for(int j=i;j<arr.Length;j++)
                {
                    if(arr[i]>arr[j])
                    {
                        int temp=arr[i];
                        arr[i]=arr[j];
                        arr[j]=temp;
                    }
                }
            }
            Console.WriteLine("The sorted Array:");
            for(int i=0;i<arr.Length;i++)
            {
                Console.Write(arr[i]+" ");
            }
        
        }
    }
}