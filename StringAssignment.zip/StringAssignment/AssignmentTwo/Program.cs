﻿using System;
namespace StringAssignmentTwo
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Given String Before Spliting:");
            string random="chennai,mumbai,kolkata";
            string[] arr=random.Split(",");
            foreach(var i in arr)
            {
                Console.WriteLine(i);
            }
        }
    }
} 