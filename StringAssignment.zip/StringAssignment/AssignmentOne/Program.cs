﻿using System;
namespace StringAssignment
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("Enter string One:");
            string one=Console.ReadLine();
            Console.Write("Enter string two:");
            string two=Console.ReadLine();
            for(int i=0;i<4;i++)
            {
                Console.Write(one[i]);
            }
            for(int i=4;i<two.Length;i++)
            {
                Console.Write(two[i]);
            }
        }
    }
}