﻿using System;
namespace OnlinePortalAssignmentOne
{
    class Program
    {
        public static void Main(string[] args)
        {
            int a,b;
            Console.WriteLine("Enter the Element A:");
            a=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Element B:");
            b=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("The Addition Of two Number is :"+(a+b));
            Console.WriteLine("The Subtraction of two Number is:"+(b-a));
            Console.WriteLine("The Multiplication of two number is:"+(a*b));
            Console.WriteLine("The Division of Two Number is:"+(a/b));
            Console.WriteLine("The Modulus of the given two number is:"+(a%b));


        }
    }
}