﻿using System;
using System.Linq;
using System.Collections.Generic;
namespace LINQQuesionTwo
{
    class Program
    {
        public static void Main(string[] args)
        {
             string[] arr={"ABU DHABI","ROME","MADURAI","LONDON","NEW DELHI","MUMBAI","NIROBI"};
            IEnumerable<string> data= from item in arr
                        orderby item.Length
                        select item;
            foreach(string i in data)
            {
                Console.WriteLine(i);
            }

        }
    }
}