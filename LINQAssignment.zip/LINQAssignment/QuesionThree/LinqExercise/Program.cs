﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            //You can get the trainee details from the GetTraineeDetails() method in TraineeData class
            Console.WriteLine("Enter Menu Number");
            int option = Convert.ToInt32(Console.ReadLine());
            TraineeDetails obj = new TraineeDetails();
            TraineeData ob1 = new TraineeData();
            List<TraineeDetails> b = ob1.GetTraineeDetails();


            switch (option)
            {
                case 1:
                    {
                        IEnumerable<string> data = from Tranee in b select (Tranee.TraineeId);
                        foreach (string items in data)
                        {
                            Console.WriteLine(items);
                        }

                        break;
                    }
                case 2:
                    {

                        IEnumerable<string> data = (from Tranee in b select (Tranee.TraineeName)).Take(3);
                        foreach (string items in data)
                        {
                            Console.WriteLine(items);
                        }
                        break;
                    }
                case 3:
                    {
                        IEnumerable<string> data = (from Tranee in b select (Tranee.TraineeName)).Skip(3);
                        foreach (string items in data)
                        {
                            Console.WriteLine(items);
                        }
                        break;
                    }
                case 4:
                    {
                        int data = b.Count();
                        Console.WriteLine(data);
                        break;
                    }
                case 5:
                    {
                        IEnumerable<string> data = from item in b
                                                   where item.YearPassedOut >= 2019
                                                   select item.TraineeName;
                        foreach (string items in data)
                        {
                            Console.WriteLine(items);
                        }

                        break;
                    }
                case 6:
                    {
                        IEnumerable<string> data = from item in b
                                                   orderby item.TraineeName
                                                   select item.TraineeName;
                        IEnumerable<string> data1 = from item in b
                                                    orderby item.TraineeName
                                                    select item.TraineeId;
                        foreach (string items in data)
                        {
                            Console.WriteLine(items);
                        }
                        foreach (string items in data1)
                        {
                            Console.WriteLine(items);
                        }
                        break;
                    }
                case 7:
                    {
                        IEnumerable<TraineeDetails> result = (from trainee in b select trainee).OrderBy(trainee => trainee.TraineeName).OrderBy(trainee => trainee.TraineeId);
                        foreach (TraineeDetails trainee in result)
                        {
                            Console.WriteLine($"TraineeID:{trainee.TraineeId},TraineeName:{trainee.TraineeName}");
                         }

                        break;
                    }
                case 8:
                    {
                        IEnumerable<int> data = (from item in b
                                                 select item.YearPassedOut).Distinct();
                        foreach (int items in data)
                        {
                            Console.WriteLine(items);
                        }
                        break;
                    }

                case 9:
                    {
                        Console.Write("Enter the Trainee ID:");
                        string traineeID = Console.ReadLine().ToUpper();
                        IEnumerable<int> marks = from trainee in b where trainee.TraineeId == traineeID select trainee.TotalScore;
                        if (marks.Count() == 0)
                        {
                            Console.WriteLine("Ivalid ID");
                        }
                        else
                        {
                            foreach (int mark in marks)
                            {
                                Console.WriteLine(mark);
                            }
                        }
                        break;
                    }
                case 10:
                    {
                        TraineeDetails trainee = b.First();
                        Console.WriteLine(trainee.TraineeId + ":" + trainee.TraineeName);
                        break;
                    }
                case 11:
                    {
                        TraineeDetails trainee = b.Last();
                        Console.WriteLine(trainee.TraineeId + ":" + trainee.TraineeName);
                        break;
                    }
                case 12:
                    {
                        IEnumerable<TraineeDetails> results = from trainee in b select trainee;
                        foreach (TraineeDetails trainee in results)
                        {
                            Console.WriteLine(trainee.TotalScore);
                        }
                        break;
                    }
                case 13:
                    {
                        int maxscore = (from trainee in b select trainee.TotalScore).Max();
                        Console.WriteLine(maxscore);
                        break;
                    }
                case 14:
                    {
                        int minscore = (from trainee in b select trainee.TotalScore).Min();
                        Console.WriteLine(minscore);
                        break;
                    }
                case 15:
                    {
                        double avgscore = (from trainee in b select trainee.TotalScore).Average();
                        Console.WriteLine(avgscore);
                        break;
                    }
                case 16:
                    {
                        bool result = (from trainee in b select trainee).All(trainee => trainee.TotalScore > 40);
                        Console.WriteLine(result);
                        break;
                    }
                case 17:
                    {
                        bool result = (from trainee in b select trainee).All(trainee => trainee.TotalScore > 20);
                        Console.WriteLine(result);
                        break;
                    }
                case 18:
                    {
                        IEnumerable<TraineeDetails> result = (from trainee in b select trainee).OrderBy(trainee => trainee.TraineeName).OrderBy(trainee => trainee.TraineeId);
                        foreach (TraineeDetails trainee in result)
                        {
                            Console.WriteLine($"TraineeID:{trainee.TraineeId},TraineeName:{trainee.TraineeName}");
                         }
                        break;
                    }



            }

        }
    }
}
