﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace LINQQuesionOne
{
    class Program
    {
        public static void Main(string[] args)
        {
            //Need To find the String Which Starts Ans Ends with Specific Character
            string[] arr={"ABU DHABI","ROME","MADURAI","LONDON","NEW DELHI","MUMBAI","NIROBI"};
            IEnumerable<string> data= from item in arr
                        where item.StartsWith('A')&&item.EndsWith('I')
                        select item;
            
            foreach(string i in data)
            {
                Console.WriteLine(i);
            }
            
        }
    }
}