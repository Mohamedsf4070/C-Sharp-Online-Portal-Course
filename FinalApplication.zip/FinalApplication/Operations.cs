using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApplication
{
    public static class Operations
    {
        public static List<Doctor> DoctorsList = new List<Doctor>();
        public static List<Patient> PatientsList = new List<Patient>();
        public static List<Appointment> Appointments = new List<Appointment>();
        public static Patient CurrentUser = null;
        public static void MainMenu()
        {
            int Option = 0;
            do
            {
                Console.WriteLine("Welcome To Doctors Plaza:");
                Console.WriteLine("\t1.Register");
                Console.WriteLine("\t2.Login");
                Console.Write("Enter Your Option:");
                Option = Convert.ToInt32(Console.ReadLine());
                switch (Option)
                {
                    case 1:
                        {
                            Registration();
                            break;
                        }
                    case 2:
                        {
                            Login();
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Enter the Correct Option");
                            break;
                        }
                }
            } while (Option != 3);
        }
        public static void Registration()
        {
            try
            {
                Console.WriteLine("Here You can Register Your Details:");
                Console.Write("Enter Your Name:");
                string name = Console.ReadLine();
                Console.Write("Enter Password:");
                string password = Console.ReadLine();
                Console.Write("Enter Your Age:");
                int age = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter your Gender:");
                Gender gender = Enum.Parse<Gender>(Console.ReadLine(), true);
                Patient patient1 = new Patient(password, name, age, gender);
                PatientsList.Add(patient1);
                Console.WriteLine("Your Registration has Done Sucessfully");
                Console.Write("Press Any to Exit:");
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void Login()
        {
            try
            {
                Console.WriteLine("_____Welcome To Login Page_____");
                Console.Write("Enter Your UserName:");
                string name = Console.ReadLine();
                int flag1 = 0, flag2 = 0;
                foreach (Patient patients in PatientsList)
                {
                    flag1 = 1;
                    if (patients.Name == name)
                    {
                        Console.Write("Enter Your Password:");
                        string password = Console.ReadLine();
                        foreach (Patient patient1 in PatientsList)
                        {
                            if (patient1.Password == password)
                            {
                                flag2 = 1;
                                CurrentUser = patient1;
                                Submenu();
                            }
                        }
                        if (flag2 == 0)
                        {
                            Console.WriteLine("You have Entered Wrong User Name Or You have Entered Wrong Password");
                        }
                    }
                }
                if (flag1 == 0)
                {
                    Console.WriteLine("You have Entered Wrong User Name Or You have Entered Wrong Password");
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void Submenu()
        {
            try
            {
                int Option = 0;
                do
                {
                    Console.WriteLine("Welcome to SubMenu Page:");
                    Console.WriteLine("\t1.BookAppointment");
                    Console.WriteLine("\t2.View Appointment Details");
                    Console.WriteLine("\t3.Edit Your Profile");
                    Console.WriteLine("\t4.Exit");
                    Console.Write("Enter Your Option:");
                    switch (Option)
                    {
                        case 1:
                            {
                                BookAppointment();
                                break;
                            }
                        case 2:
                            {
                                ViewAppointmentHistory();
                                break;
                            }
                        case 3:
                            {
                                EditYourProfile();
                                break;
                            }
                        case 4:
                            {
                                break;
                            }
                    }
                    Option = Convert.ToInt32(Console.ReadLine());
                } while (Option != 4);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void BookAppointment()
        {
            try
            {
                Console.WriteLine("Select the Department from the Below List:");
                Console.WriteLine("1.Anaesthesiology\n2.Cardiology\n3.Diabetology\n4.Neonatology");
                Console.Write("\nEnter Your Choice:");
                string choice = Console.ReadLine();
                int flag = 0;
                foreach (Doctor doctors in DoctorsList)
                {
                    if (doctors.Department == choice)
                    {
                        flag = 1;
                        DateTime date = DateTime.Now;
                        Appointment appointment1 = new Appointment(CurrentUser.Password, doctors.DoctorID, date, doctors.Problem);
                        Console.WriteLine("Your Appointment was Confirmed for the date " + date.ToString("dd/MM/yyyy"));
                        Appointments.Add(appointment1);
                        Console.Write("Press Any key to Exit");
                    }
                }
                if (flag == 0)
                {
                    Console.WriteLine("You have Entered Wrong Department Name");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void ViewAppointmentHistory()
        {
            Console.WriteLine("Here you  can see Your Appointment History:");
            foreach (Appointment appointment in Appointments)
            {
                if (appointment.PatientID == CurrentUser.PatientID)
                {
                    Console.WriteLine($"{appointment.AppointmentID},{appointment.PatientID},{appointment.DoctorID},{appointment.AppointmentDate},{appointment.Problem}");
                }
            }
        }
        public static void EditYourProfile()
        {
            Console.WriteLine("Here You can Edit Your Profile:");
            Console.Write("Enter Your Name:");
            string name = Console.ReadLine();
            CurrentUser.Name=name;
            Console.Write("Enter Password:");
            string password = Console.ReadLine();
            CurrentUser.Password=password;
            Console.Write("Enter Your Age:");
            int age = Convert.ToInt32(Console.ReadLine());
            CurrentUser.Age=age;
            Console.Write("Enter your Gender:");
            Gender gender = Enum.Parse<Gender>(Console.ReadLine(), true);
            CurrentUser.GenDer=gender;
        }

        public static void AddDefaultData()
        {
            //Patient Details
            Patient patient1 = new Patient("Ronaldo007", "Mohamed", 22, Gender.Male);
            PatientsList.Add(patient1);
            //Doctor Details
            Doctor doctor1 = new Doctor("Nancy", "Anaesthesiology", "Heart Problem");
            DoctorsList.Add(doctor1);
            Doctor doctor2 = new Doctor("Andrew", "Cardiology", "Heart Muscles Problem");
            DoctorsList.Add(doctor2);
            Doctor doctor3 = new Doctor("Janet", "Diabetology", "Sugar Level Problem");
            DoctorsList.Add(doctor3);
            Doctor doctor4 = new Doctor("Margaret", "Neonatology", "Neural Problem");
            DoctorsList.Add(doctor4);


        }
    }
}