using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApplication
{
    public class Doctor
    {
        /// <summary>
        /// Private static int DoctorID
        /// </summary>
        private static int s_doctorID=1000;
        /// <summary>
        /// Public Stirng DoctorID
        /// </summary>
        public string DoctorID{get;set;}
        /// <summary>
        /// Public string DoctorName
        /// </summary>
        public string DoctorName{get;set;}
        /// <summary>
        /// public string Department
        /// </summary>
        public string Department{get;set;}
        public string Problem{get;set;}
        /// <summary>
        /// Constructor for Class Doctor
        /// </summary>
        /// <param name="doctorName"> Name of the Doctor</param>
        /// <param name="department"> Department Of the Doctor</param>
        public Doctor(string doctorName,string department,string problem)
        {
            s_doctorID++;
            DoctorID="DID"+s_doctorID;
            DoctorName=doctorName;
            Department=department;
            Problem=problem;
        }
    }
}