using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApplication
{
    public enum Gender{select,Male,Female}
    public class Patient
    {
        /// <summary>
        /// private static int Patient ID
        /// </summary>
        private static int s_patientID=1000;
        /// <summary>
        /// Public string Patient ID
        /// </summary>
        public string PatientID{get;set;}
        /// <summary>
        /// Public string Password
        /// </summary>
        public string Password{get;set;}
        /// <summary>
        /// Public string Name
        /// </summary>
        public string Name{get;set;}
        /// <summary>
        /// Public int Age
        /// </summary>
        public int Age{get;set;}
        /// <summary>
        /// Public Enum Gender
        /// </summary>
        public Gender GenDer{get;set;}
        /// <summary>
        /// Constructor for Patient class
        /// </summary>
        /// <param name="password"> Password of the User </param>
        /// <param name="name"> Name of the Patuient </param>
        /// <param name="age"> Age of the Patient</param>
        /// <param name="gender"> Gender of the Patient </param>
        public Patient(string password,string name,int age,Gender gender)
        {
            s_patientID++;
            PatientID="PID"+s_patientID;
            Password=password;
            Name=name;
            Age=age;
            GenDer=gender;
        }
    }
}