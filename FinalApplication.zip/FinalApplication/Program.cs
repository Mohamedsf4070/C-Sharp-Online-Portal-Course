﻿using System;
namespace FinalApplication
{
    class Program
    {
        public static void Main(string[] args)
        {
            Operations.AddDefaultData();
            Operations.MainMenu();
        }
    }
}