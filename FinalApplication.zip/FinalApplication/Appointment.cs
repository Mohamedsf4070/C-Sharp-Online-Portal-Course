using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalApplication
{
    public class Appointment
    {
        /// <summary>
        /// private static int Apppointment id
        /// </summary>
        private static int s_appointmentID=1000;
        /// <summary>
        /// Public string Appointment ID
        /// </summary>
        public string AppointmentID{get;set;}
        /// <summary>
        /// Public string Patient ID
        /// </summary>
        public string PatientID{get;set;}
        /// <summary>
        /// Public string Doctor ID
        /// </summary>
        public string DoctorID{get;set;}
        /// <summary>
        /// Public string Appointment Date
        /// </summary>
        public DateTime AppointmentDate{get;set;}
        /// <summary>
        /// public string Problem
        /// </summary>
         public string Problem{get;set;}
         /// <summary>
         /// Constructor of Appointment Class
         /// </summary>
         /// <param name="patientID"> ID of the Patient</param>
         /// <param name="doctorID"> ID of the Doctor</param>
         /// <param name="appointmentDate"> Appointment date OF The Appointment</param>
         /// <param name="problem"> Problem for the Appointment</param>
        public Appointment(string patientID,string doctorID,DateTime appointmentDate,string problem)
        {
            s_appointmentID++;
            AppointmentID="AID"+s_appointmentID;
            PatientID=patientID;
            DoctorID=doctorID;
            AppointmentDate=appointmentDate;
            Problem=problem;
        }
    }
}