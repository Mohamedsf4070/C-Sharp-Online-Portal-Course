﻿using System;
namespace DateTimeAssignment
{
    class Program
    {
        public static void Main(string[] args)
        {
            DateTime date;
            Console.Write("Enter a Date:");
            date = new DateTime(2000, 10, 11, 11, 20, 33);
            Console.WriteLine("The month of the Date is:" + date.ToString("MMMM"));
            DateTime PreviousDate = date.AddDays(-3);
            Console.WriteLine("Previous date of the Current Day is:" + PreviousDate.ToString("dd/MM/yyyy"));
            int i = date.Hour;
            Console.WriteLine("12 hours from Now is:");

            for (int j = 0; j < 12; j++)
            {
                if (i <= 12)
                {
                    i++;
                    if (i > 12)
                    {
                        i = 1;

                    }
                    Console.Write(i + " ");

                }

            }
        }
    }
}