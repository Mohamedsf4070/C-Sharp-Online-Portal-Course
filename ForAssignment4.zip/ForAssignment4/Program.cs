﻿using System;
namespace OnlinePortalForAssignment
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter ten Numbers:");
            int sum=0;
            for(int i=0;i<10;i++)
            {
             int n=Convert.ToInt32(Console.ReadLine());
             sum+=n;
            }
            Console.WriteLine("Total sum of the Given 10 Numbers is:"+sum);
            double average=sum/10;
            Console.WriteLine("Average of the Given 10 Numbers is:"+average);
        }
    }
}